﻿aes_tv_0000001-0005000_power.csv : CPA研修の解析用波形データ(1/2)
aes_tv_0005001-0010000_power.csv : CPA研修の解析用波形データ(2/2)
CIPHERTEXT10000.txt : 10000波形分の暗号文のテキストファイル
